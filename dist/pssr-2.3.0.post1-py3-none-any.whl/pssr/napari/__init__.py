from .widgets import TrainWidget, PredictWidget
